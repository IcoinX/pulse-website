# PULSE Protocol Audit Summary

**Timestamp:** 2026-02-19T02:31:01.494Z  
**URL:** https://pulseprotocol.co

## Global Verdict

- ✅ PASS: 1
- ⚠️ WARN: 4
- ❌ FAIL: 0

## Issues

- **WARN**: Could not click Live / Breaking tab
- **WARN**: Could not click New Agents tab
- **WARN**: Could not click Trending tab
- **WARN**: Could not click Research tab

## Stats

- Events extracted: 30
- Console errors: 0
- Network failures: 0

## Command

```bash
npm run audit:pulse
```
